package com.example.jerryminotta.practica4jerryminotta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RenglonContacto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renglon_contacto);
    }
}
